from flask import Flask, render_template
from flask_login import login_user
from werkzeug.utils import redirect
import sqlalchemy
from .db_session import SqlAlchemyBase
from untitled.data import db_session
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)

student_1 = {
    'loginn': '7216492038',
    'parol': '3125469040'
}

student_2 = {
    'loginn': '35G6',
    'parol': '0LS1T'
}
app.config['SECRET_KEY'] = '_my_life_self_'


@app.route('/edutatar', methods=['GET', 'POST'])
class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class User(SqlAlchemyBase):
    __tablename__ = 'passwords'
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    loginn = sqlalchemy.Column(sqlalchemy.String,
                              index=True, unique=True, nullable=True)
    parol = sqlalchemy.Column(sqlalchemy.String, nullable=True)


def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('qwerty.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('qwerty.html', title='Авторизация', form=form)


def proverka():
    if student_1:
        return render_template('boy.html')

    elif student_2:
        return render_template('girl.html')
    else:
        return 'ERROR'


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
